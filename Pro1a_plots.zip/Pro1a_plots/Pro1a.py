from mpl_toolkits.mplot3d import Axes3D
import matplotlib.pyplot as plt
from matplotlib import cm
from matplotlib.ticker import LinearLocator, FormatStrFormatter
import numpy as np
from random import random, seed

# To keep the same eps in the FrankeFunction
np.random.seed(0)
error=0.01
# Make data
x = np.arange(0, 1, 0.05)
y = np.arange(0, 1, 0.05)
x, y = np.meshgrid(x,y)


def FrankeFunction(x,y):
    term1 = 0.75*np.exp(-(0.25*(9*x-2)**2) - 0.25*((9*y-2)**2))
    term2 = 0.75*np.exp(-((9*x+1)**2)/49.0 - 0.1*(9*y+1))
    term3 = 0.5*np.exp(-(9*x-7)**2/4.0 - 0.25*((9*y-3)**2))
    term4 = -0.2*np.exp(-(9*x-4)**2 - (9*y-7)**2)
    eps = error*np.random.randn(len(x),1)
    return term1 + term2 + term3 + term4 + eps


z = FrankeFunction(x, y)

def CreateDesignMatrix_X(x, y, n = 5):
	"""
	Function for creating a design X-matrix with rows [1, x, y, x^2, xy, xy^2 , etc.]
	Input is x and y mesh or raveled mesh, keyword agruments n is the degree of the polynomial you want to fit.
	"""
	if len(x.shape) > 1:
		x = np.ravel(x)
		y = np.ravel(y)

	N = len(x)
	l = int((n+1)*(n+2)/2)		# Number of elements in beta
	X = np.ones((N,l))

	for i in range(1,n+1):
		q = int((i)*(i+1)/2)
		for k in range(i+1):
			X[:,q+k] = x**(i-k)*y**k
	return X


# OLS Regression    
X = CreateDesignMatrix_X(x,y,n=5)
z = np.ravel(z)
beta = np.linalg.inv(X.T.dot(X)).dot(X.T).dot(z)
z_tilde = X @ beta

# Reshape z-values for plotting
z_tilde = z_tilde.reshape(20,20)
z = z.reshape(20,20)

# Plotting
fig = plt.figure("Real Surface")
ax = fig.gca(projection='3d')
surf = ax.plot_surface(x, y, z_tilde, cmap=cm.coolwarm,
                       linewidth=0, antialiased=False)
ax.set_xlabel('Y')
ax.set_ylabel('X')
ax.set_zlabel('Z')
# Customize the z axis.
ax.set_zlim(-0.10, 1.40)
ax.zaxis.set_major_locator(LinearLocator(10))
ax.zaxis.set_major_formatter(FormatStrFormatter('%.02f'))

# Add a color bar which maps values to colors.
fig.colorbar(surf, shrink=0.5, aspect=5)

# Plotting
fig = plt.figure("Approximated surface")
ax = fig.gca(projection='3d')
surf = ax.plot_surface(x, y, z, cmap=cm.coolwarm,
                       linewidth=0, antialiased=False)
ax.set_xlabel('Y')
ax.set_ylabel('X')
ax.set_zlabel('Z')
# Customize the z axis.
ax.set_zlim(-0.10, 1.40)
ax.zaxis.set_major_locator(LinearLocator(10))
ax.zaxis.set_major_formatter(FormatStrFormatter('%.02f'))

# Add a color bar which maps values to colors.
fig.colorbar(surf, shrink=0.5, aspect=5)

def variance(y):
    ey = np.zeros(len(y))
    ey[:] = 1./(len(y))*np.sum(y)
    return(1./(len(y)))*np.sum((y - ey)**2)

def MSE(y,y_tilde):
    return(1/len(y))*np.sum((y - y_tilde)**2)

def R2score(y,y_tilde):
    ey = np.zeros(len(y_tilde))
    ey[:] = 1./(len(y_tilde))*np.sum(y_tilde)
    return 1 - sum((y - y_tilde)**2)/sum((y - ey)**2)

# Function for confidence interval
def confidence(beta,error):
    V=np.diag(np.linalg.inv(X.T.dot(X)))
    for i in range(len(beta)):
        print("Beta",i, beta[i]-1.96*V[i]**(0.5)*error, beta[i]+1.96*V[i]**(0.5)*error)
        mini.append(beta[i]-1.96*V[i]**(0.5)*error)
        maxi.append(beta[i]+1.96*V[i]**(0.5)*error)
# Plots and prints out the confidence interval of beta using the optimal lambda
mini=[]
maxi=[]
z = np.ravel(z)
z_tilde = np.ravel(z_tilde)
print("_____Confidence Intervals_____")
confidence(beta,error)
plt.figure()
plt.title("Span of confidence interval")
plt.plot(range(21),maxi-beta,"ro",label="Beta max-Beta")
plt.ylabel("Span")
plt.xlabel("Beta0, Beta1, ..., BetaN")
plt.legend()
plt.grid()
plt.figure("Beta, Beta min, Beta max")
plt.title("Beta, Beta min, Beta max")
plt.plot(range(21),beta,"r",label="Beta")
plt.plot(range(21),mini,"b",label="Beta min")
plt.plot(range(21),maxi,"g",label="Beta max")
plt.ylabel("Beta")
plt.xlabel("Beta0, Beta1, ..., BetaN")
plt.legend()
plt.grid()
# The approximated data is then used to find the variance, MSE and the R2-score
zvar = variance(z_tilde)
betavar = zvar*np.linalg.inv(X.T.dot(X)) #Variance of beta
zmse = MSE(z,z_tilde)
zr2 = R2score(z,z_tilde)
# Prints out the results
print("_____Variance of beta_____")
print(betavar)
print("_____Mean squared error_____")
print(zmse)
print("_____R2-score_____")
print(zr2)
plt.show()
