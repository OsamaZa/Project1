import numpy as np
from random import random, seed
import matplotlib.pyplot as plt
from sklearn.linear_model import Lasso

# To keep the same eps in the FrankeFunction
np.random.seed(0)

# Make data.
x = np.arange(0, 1, 0.05)
y = np.arange(0, 1, 0.05)
x, y = np.meshgrid(x,y)


def FrankeFunction(x,y):
    term1 = 0.75*np.exp(-(0.25*(9*x-2)**2) - 0.25*((9*y-2)**2))
    term2 = 0.75*np.exp(-((9*x+1)**2)/49.0 - 0.1*(9*y+1))
    term3 = 0.5*np.exp(-(9*x-7)**2/4.0 - 0.25*((9*y-3)**2))
    term4 = -0.2*np.exp(-(9*x-4)**2 - (9*y-7)**2)
    eps = np.random.randn(len(x),1)
    return term1 + term2 + term3 + term4 + eps


z = FrankeFunction(x, y)

def CreateDesignMatrix_X(x, y, n = 5):
	"""
	Function for creating a design X-matrix with rows [1, x, y, x^2, xy, xy^2 , etc.]
	Input is x and y mesh or raveled mesh, keyword agruments n is the degree of the polynomial you want to fit.
	"""
	if len(x.shape) > 1:
		x = np.ravel(x)
		y = np.ravel(y)

	N = len(x)
	l = int((n+1)*(n+2)/2)		# Number of elements in beta
	X = np.ones((N,l))

	for i in range(1,n+1):
		q = int((i)*(i+1)/2)
		for k in range(i+1):
			X[:,q+k] = x**(i-k)*y**k
	return X

def variance(y):
    ey = np.zeros(len(y))
    ey[:] = 1./(len(y))*np.sum(y)
    return(1./(len(y)))*np.sum((y - ey)**2)

def MSE(y,y_tilde):
    return(1/len(y))*np.sum((y - y_tilde)**2)

def R2score(y,y_tilde):
    ey = np.zeros(len(y_tilde))
    ey[:] = 1./(len(y_tilde))*np.sum(y_tilde)
    return 1 - sum((y - y_tilde)**2)/sum((y - ey)**2)

nlambdas = 5 # Number of lambdas
lambdas = np.logspace(-8,-6,nlambdas) # Lambdas used in the for-loop
k = 5 # k=5 cross valdation
p = 12 # Highest polynomial p-1 is used to approximate
d = 0
z = np.ravel(z)
degree = np.arange(2,p) # # Range of the polynomial degree
scores_error = np.zeros(nlambdas) # List to be filled with the errors calculated
scores_r2score = np.zeros(nlambdas) # List to be filled with the r2 scores calculated
for lmb in lambdas:
    # Lists to be filled with results
    error = np.zeros(p-2)
    bias = np.zeros(p-2)
    var = np.zeros(p-2)
    trainingerror = np.zeros(p-2)
    r2score = np.zeros(p-2)
    # The polynomial for-loop
    for j in range(2,p):
        # Calling the design matrix
        X = CreateDesignMatrix_X(x,y,n = j)
        X = X[:,1:]
        # Making a list of numbers which will act as our indexes when resampling initiated
        indexes = np.arange(X.shape[0])
        # Shuffle the indexes and split them
        np.random.shuffle(indexes)
        s = np.split(indexes,k)
        # List that will be filled
        errorarray = np.zeros(k)
        biasarray = np.zeros(k)
        variancearray = np.zeros(k)
        trainingerrorarray = np.zeros(k)
        r2scorearray = np.zeros(k)
        # The cross validation for-loop
        for i in range(k):
            # Making the test and train data
            X_test = X[s[i]]
            z_test = z[s[i]]
            a = np.delete(s,i,0) # Removing the test data indexes
            a = a.flatten()
            X_train = X[a]
            z_train = z[a]
            # Lasso regression
            lasso = Lasso(alpha=lmb,max_iter = 10e4).fit(X_train,z_train)
            z_tilde = lasso.predict(X_test) # Testing the model
            # Calculating the erro, the bias and the variance and add them to lists
            errorarray[i] = np.mean((z_test - z_tilde)**2)
            biasarray[i] = np.mean((z_train - np.mean(z_tilde))**2)
            variancearray[i] = variance(z_tilde)
            z_tilde_train = lasso.predict(X_train) # Training data used to make an approximate
            trainingerrorarray[i] = np.mean((z_train - z_tilde_train)**2)
            r2scorearray[i] = R2score(z_test,z_tilde)
        # Calculate the mean of test error, bias, variance and the training error for the cross validation
        error[j-2] = np.mean(errorarray)
        bias[j-2] = np.mean(biasarray)
        var[j-2] = np.mean(variancearray)
        trainingerror[j-2] = np.mean(trainingerrorarray)
        r2score[j-2] = np.mean(r2scorearray)
        if j == 5: # The number here will dictate from what polynomial the error and r2-score is saved
            # This is done to be able to decide which lambda gives the best error and r2 score
            scores_error[d] = error[j-2]
            scores_r2score[d] = r2score[j-2]
    # Plots the error, variance and bias vs model complexity        
    plt.figure()
    plt.plot(degree,error,"r-",label="error")
    plt.plot(degree,bias,"b-",label="bias")
    plt.plot(degree,var,"g-",label="var")
    plt.xlabel("Model complexity")
    plt.title("Bias, variance and error as function of model complexity for lamda=%.10f" %lmb)
    plt.legend()
    plt.grid()
    # Plots the error, variance and trainingerror vs model complexity
    plt.figure()
    plt.plot(degree,error,"r-",label="error")
    plt.plot(degree,trainingerror,"b-",label="bias")
    plt.plot(degree,var,"g-",label="var")
    plt.xlabel("Model complexity")
    plt.title("Bias, variance and error as function of model complexity for lamda=%.10f" %lmb)
    plt.legend()
    plt.grid()
    # Plots the test error and the training error vs model complexity
    plt.figure()
    plt.plot(degree,error,"r-",label="test error")
    plt.plot(degree,trainingerror,"b-",label="training error")
    plt.xlabel("Model complexity")
    plt.ylabel("Error")
    plt.title("Error as function of model complexity for lambda=%.10f" %lmb)
    plt.legend()
    plt.grid()
    d += 1
    
# Finding the lowest MSE for the given lambda and complexity
result_error = (np.where(scores_error == np.min(scores_error)))
result_r2score = (np.where(scores_r2score == np.min(scores_error)))
print(result_error,result_r2score)
print("Minimum mean error is", scores_error[int(result_error[0])], "and happens for lambda=%.10f" %lambdas[int(result_error[0])])
print("Makimum r2 score is", scores_r2score[int(result_error[0])], "and happens for lambda=%.10f" %lambdas[int(result_error[0])])
# Plots the lambdas vs mean error for each lambda
plt.figure()
plt.plot(np.log10(lambdas),scores_error)
plt.title("Mean error vs lambda")
plt.xlabel("log lambda")
plt.ylabel("mean error")
plt.grid()
# Finds the optimal lambda which gave lowest error for the given complexity
optimal_lambda = lambdas[int(result_error[0])]

# A cross validation for loop for average beta
X = CreateDesignMatrix_X(x,y,n = 5)
X = X[:,1:]
betas = np.zeros((len(X.T.dot(X)[0]),5))
for i in range(5):
    # making the test and train loop
    X_test = X[s[i]]
    z_test = z[s[i]]
    a = np.delete(s,i,0)
    a = a.flatten()
    X_train = X[a]
    z_train = z[a]
    # lasso regression
    lasso = Lasso(alpha=optimal_lambda,max_iter = 10e4).fit(X_train,z_train)
    beta = lasso.coef_
    # storing the betas
    betas[:,i] = beta
    
# Function for confidence interval    
def confidence(beta,error):
    V=np.diag(np.linalg.inv(X.T.dot(X)))
    for i in range(len(beta)):
        mini.append(beta[i]-1.96*V[i]**(0.5)*error/np.sqrt(k-1))
        maxi.append(beta[i]+1.96*V[i]**(0.5)*error/np.sqrt(k-1))
        
# Finding the average beta
beta = np.zeros(len(X.T.dot(X)[0]))
for i in range(len(X.T.dot(X)[0])):
    beta[i] = np.mean(betas[i,:])
    
# Plots and prints out the confidence interval of beta using the optimal lambda
mini=[]
maxi=[]
confidence(beta,0.01)
print(maxi)
plt.figure()
plt.title("Span of confidence interval")
plt.plot(range(len(beta)),maxi-beta,"ro")
plt.ylabel("Span")
plt.xlabel("Beta0, Beta1, ..., BetaN")
plt.grid()

plt.figure("Beta, Beta min, Beta max")
plt.title("Beta")
plt.plot(range(len(beta)),beta,"r",label="Beta")
plt.ylabel("Beta")
plt.xlabel("Beta0, Beta1, ..., BetaN")
plt.legend()
plt.grid()

plt.show() 
