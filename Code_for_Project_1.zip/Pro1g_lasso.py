import numpy as np
from imageio import imread
import matplotlib.pyplot as plt
from mpl_toolkits.mplot3d import Axes3D
from matplotlib import cm
from matplotlib.ticker import LinearLocator, FormatStrFormatter
from sklearn.linear_model import Lasso
np.random.seed(0)
# Load the terrain
terrain = imread("Oslofjord.tif")

# Making the x and y points
x = np.linspace(0,1,1801)
y = np.linspace(0,1,3601)
x,y = np.meshgrid(x,y)

def CreateDesignMatrix_X(x, y, n = 5):
    """
    Function for creating a design X-matrix with rows [1, x, y, x^2, xy, xy^2 , etc.]
    Input is x and y mesh or raveled mesh, keyword agruments n is the degree of the polynomial you want to fit.
    """
    if len(x.shape) > 1:
        x = np.ravel(x)
        y = np.ravel(y)

    N = len(x)
    l = int((n+1)*(n+2)/2)		# Number of elements in beta
    X = np.ones((N,l))

    for i in range(1,n+1):
        q = int((i)*(i+1)/2)
        for k in range(i+1):
            X[:,q+k] = x**(i-k)*y**k
    return X

def variance(y):
    ey = np.zeros(len(y))
    ey[:] = 1./(len(y))*np.sum(y)
    return(1./(len(y)))*np.sum((y - ey)**2)

def MSE(y,y_tilde):
    return(1/len(y))*np.sum((y - y_tilde)**2)

def R2score(y,y_tilde):
    ey = np.zeros(len(y_tilde))
    ey[:] = 1./(len(y_tilde))*np.sum(y_tilde)
    return 1 - sum((y - y_tilde)**2)/sum((y - ey)**2)

nlambdas = 5 # Number of lambdas
lambdas = np.logspace(-6,-2,nlambdas) # Lambdas used in the for-loop
k = 5 # k=5 cross validation
d = 0
z = np.ravel(terrain)
X = CreateDesignMatrix_X(x,y,n=5) # Calling the design matrix which is based on a fifth degree polynomial
X = np.delete(X,-1,0)# Removing some data so the data can be divided in 5. This is for the cross validation
X = X[:,1:]
# List will be filled with results
error = np.zeros(nlambdas)
r2score = np.zeros(nlambdas)
meanbetas = np.zeros((21,nlambdas)) 
for lmb in lambdas:
    # Making a list of numbers which will act as the indexes in the resampling
    indexes = np.arange(X.shape[0])
    np.random.shuffle(indexes)
    # Shuffle the indexes and splits them
    s = np.split(indexes,k)
    # Lists that will be filled
    errorarray = np.zeros(k)
    r2scorearray = np.zeros(k)
    # The cross validation for-loop
    betas = np.zeros((21,k))
    for i in range(k):
        # Making the test and train data
        X_test = X[s[i]]
        z_test = z[s[i]]
        a = np.delete(s,i,0) # Removing the test data indexes
        a = a.flatten()
        X_train = X[a]
        z_train = z[a]
        # Lasso regression
        lasso = Lasso(alpha=lmb,max_iter = 1000).fit(X_train,z_train)
        z_tilde = lasso.predict(X_test)
        beta = np.zeros(21)
        beta[0] = lasso.intercept_
        beta[1:21] = lasso.coef_
        # Calculating the error
        errorarray[i] = np.mean((z_test - z_tilde)**2)
        r2scorearray[i] = R2score(z_test,z_tilde)
        betas[:,i] = beta
    for i in range(len(beta)):
        beta[i] = np.mean(betas[i,:])
    meanbetas[:,d] = beta
    # Calculating the mean of error for the crossvalidation
    error[d] = np.mean(errorarray)
    r2score[d] = np.mean(r2scorearray)
    d += 1
# Finding the lowest MSE for the given lambda and complexity
result = (np.where(error == np.min(error)))
print("Minimum MSE is", error[result[0]], "and it happens for lambda=%.10f" %lambdas[result[0]])
print("The r2 score for lambda with smallest error is", r2score[result[0]])
# Plots the lambdas vs mean error for each lambda
plt.figure()
plt.plot(lambdas,error,"r-",label="error")
plt.xscale("Log")
plt.xlabel("Lambda")
plt.ylabel("Error")
plt.title("Error as function of lambda")
plt.legend()
plt.grid()


# Function for confidence interval
def confidence(beta,error):
    V=np.diag(np.linalg.inv(X.T.dot(X)))
    for i in range(len(beta)):
        mini.append(beta[i]-1.96*V[i]**(0.5)*error)
        maxi.append(beta[i]+1.96*V[i]**(0.5)*error)

# Finds the optimal lambda which gave lowest error
optimal_lambda = lambdas[result[0]]
X = CreateDesignMatrix_X(x,y,n = 5)
# Plots and prints out the confidence interval of beta using the optimal lambda
mini=[]
maxi=[]
confidence(beta,np.sqrt(variance(z)))
print(maxi)
plt.figure("Beta, Beta min, Beta max")
plt.title("Beta, Beta min, Beta max")
plt.plot(range(len(beta)),maxi,"g",label="Beta max")
plt.plot(range(len(beta)),mini,"r",label="Beta mini")
plt.plot(range(len(beta)),beta,"b",label="Beta")
plt.legend()
plt.grid()

# Uses the optimal lambda to make an approximation
lasso = Lasso(alpha=optimal_lambda,max_iter = 1000).fit(X,z)
z_tilde = lasso.predict(X)

# Reshape for plotting
z_tilde = z_tilde.reshape(3601,1801)
z = z.reshape(3601,1801)

# Plotting the surfaces
fig = plt.figure()
ax = fig.gca(projection='3d')
surf = ax.plot_surface(y, x, z_tilde, cmap=cm.coolwarm,
                       linewidth=0, antialiased=False)
ax.set_xlabel('Y')
ax.set_ylabel('X')
ax.set_zlabel('Z')
# Customize the z axis.
ax.set_zlim(-0.1, 1380)
ax.zaxis.set_major_locator(LinearLocator(10))
ax.zaxis.set_major_formatter(FormatStrFormatter('%.02f'))
# Add a color bar which maps values to colors.
fig.colorbar(surf, shrink=0.5, aspect=5)

# Plotting the surfaces
fig = plt.figure()
ax = fig.gca(projection='3d')
surf = ax.plot_surface(y, x, z, cmap=cm.coolwarm,
                       linewidth=0, antialiased=False)
ax.set_xlabel('Y')
ax.set_ylabel('X')
ax.set_zlabel('Z')
# Customize the z axis.
ax.set_zlim(-0.1, 1380)
ax.zaxis.set_major_locator(LinearLocator(10))
ax.zaxis.set_major_formatter(FormatStrFormatter('%.02f'))
# Add a color bar which maps values to colors.
fig.colorbar(surf, shrink=0.5, aspect=5)

# Show the terrain
plt.figure()
plt.title('Terrain over Oslofjord')
plt.imshow(terrain, cmap='gnuplot')
plt.xlabel('X')
plt.ylabel('Y')

# Show the terrain
plt.figure()
plt.title('Approximated terrain over Oslofjord')
plt.imshow(z_tilde, cmap='gnuplot')
plt.xlabel('X')
plt.ylabel('Y')

plt.show()

