import numpy as np
from random import random, seed
import matplotlib.pyplot as plt

# To keep the same eps in the FrankeFunction
np.random.seed(0)
err=0.01
# Make data.
x = np.arange(0, 1, 0.05)
y = np.arange(0, 1, 0.05)
x, y = np.meshgrid(x,y)


def FrankeFunction(x,y):
    term1 = 0.75*np.exp(-(0.25*(9*x-2)**2) - 0.25*((9*y-2)**2))
    term2 = 0.75*np.exp(-((9*x+1)**2)/49.0 - 0.1*(9*y+1))
    term3 = 0.5*np.exp(-(9*x-7)**2/4.0 - 0.25*((9*y-3)**2))
    term4 = -0.2*np.exp(-(9*x-4)**2 - (9*y-7)**2)
    eps = err*np.random.randn(len(x),1)
    return term1 + term2 + term3 + term4 + eps

z = FrankeFunction(x, y)

def CreateDesignMatrix_X(x, y, n = 5):
	"""
	Function for creating a design X-matrix with rows [1, x, y, x^2, xy, xy^2 , etc.]
	Input is x and y mesh or raveled mesh, keyword agruments n is the degree of the polynomial you want to fit.
	"""
	if len(x.shape) > 1:
		x = np.ravel(x)
		y = np.ravel(y)

	N = len(x)
	l = int((n+1)*(n+2)/2)		# Number of elements in beta
	X = np.ones((N,l))

	for i in range(1,n+1):
		q = int((i)*(i+1)/2)
		for k in range(i+1):
			X[:,q+k] = x**(i-k)*y**k
	return X

def variance(y):
    ey = np.zeros(len(y))
    ey[:] = 1./(len(y))*np.sum(y)
    return (1./(len(y)))*np.sum((y - ey)**2)

def R2score(y,y_tilde):
    ey = np.zeros(len(y_tilde))
    ey[:] = 1./(len(y_tilde))*np.sum(y_tilde)
    return 1 - sum((y - y_tilde)**2)/sum((y - ey)**2)

k = 5 # k=5 fold cross validation
p = 12 # Highest polynomial used to approximate, starts with 0 ends with p=10
# List which will be filled
error = np.zeros(p)
bias = np.zeros(p)
var = np.zeros(p)
degree = np.zeros(p)
trainingerror = np.zeros(p)
r2score = np.zeros(p)
z = np.ravel(z)
betas = np.zeros((21,5))

# The polynomial for-loop
for j in range(0,p):
    # Calling the design matrix
    X = CreateDesignMatrix_X(x,y,n = j)
    # Making a list of numbers which will act as the indexes in the resampling
    indexes = np.arange(X.shape[0])
    # Shuffel the indexes and then split the list
    np.random.shuffle(indexes)
    s = np.split(indexes,k)
    # List which will be filled
    errorarray = np.zeros(k)
    biasarray = np.zeros((k,len(s[0])))
    variancearray = np.zeros(k)
    trainingerrorarray = np.zeros(k)
    r2scorearray = np.zeros(k)
    # The cross validation for loop
    for i in range(k):
        # Making the test and train data
        X_test = X[s[i]]
        z_test = z[s[i]]
        a = np.delete(s,i,0)
        a = a.flatten()
        X_train = X[a]
        z_train = z[a]
        # OLS regression
        beta = np.linalg.inv(X_train.T.dot(X_train)).dot(X_train.T).dot(z_train)
        z_tilde = X_test @ beta
        # Calculating the error, the bias and the variance and add the to lists/matrixes
        errorarray[i] = np.mean((z_test - z_tilde)**2)
        biasarray[i] = (z_test - np.mean(z_tilde))**2
        variancearray[i] = variance(z_tilde)
        # Making the train data and the error for the train data
        z_tilde_train = X_train @ beta
        trainingerrorarray[i] = np.mean((z_train - z_tilde_train)**2)
        # Calculating the r2 score
        r2scorearray[i] = R2score(z_test,z_tilde)
        # Storing the betas for the 5th degree polynom
        if j == 5: # The number here will dictate from what polynomial the error and r2-score is saved
            betas[:,i] = beta
    # Calculate the mean of test error, bias, variance and the training error for the crossvalidation
    error[j] = np.mean(errorarray)
    bias[j] = np.mean(biasarray)
    var[j] = np.mean(variancearray)
    degree[j] = j
    trainingerror[j] = np.mean(trainingerrorarray)
    r2score[j] = np.mean(r2scorearray)

print("Mean error from OLS, using 5th degree polynom, is", error[4])
print("R2 score from OLS, using 5th degree polynom, is", r2score[4])
# Finding the average beta
beta = np.zeros(21)
for i in range(21):
    beta[i] = np.mean(betas[i,:])

# Function for confidence interval
def confidence(beta,error):
    V=np.diag(np.linalg.inv(X.T.dot(X)))
    for i in range(len(beta)):
        mini.append(beta[i]-1.96*V[i]**(0.5)*error/np.sqrt(k-1))
        maxi.append(beta[i]+1.96*V[i]**(0.5)*error/np.sqrt(k-1))

# Plots and prints out the confidence interval of beta using the optimal lambda
mini=[]
maxi=[]
confidence(beta,err)
print(maxi)
plt.figure()
plt.title("Span of confidence interval")
plt.plot(range(len(beta)),maxi-beta,"ro",label="Beta max-Beta")
plt.ylabel("Span")
plt.xlabel("Beta0, Beta1, ..., BetaN")
plt.legend()
plt.grid()
plt.figure("Beta")
plt.title("Beta")
plt.plot(range(len(beta)),beta,"r",label="Beta")
plt.ylabel("Beta")
plt.xlabel("Beta0, Beta1, ..., BetaN")
plt.legend()
plt.grid()

# Ploting the test error, bias and variance againts the model complexity
plt.figure()
plt.plot(degree,error,"r-",label="error")
plt.plot(degree,trainingerror,"b-",label="bias")
plt.plot(degree,var,"g-",label="var")
plt.xlabel("Model complexity")
plt.title("Bias, variance and error as function of model complexity")
plt.legend()
plt.grid()

# Ploting the test and training error against the model complexity
plt.figure()
plt.plot(degree,error,"r-",label="test error")
plt.plot(degree,trainingerror,"b-",label="training error")
plt.xlabel("Model complexity")
plt.ylabel("Error")
plt.title("Error as function of model complexity")
plt.legend()
plt.grid()

k = 5 # k=5 fold cross validation
npoints = 12 # Used to make the diffrent lengths of datapoints
# List which will be filled
error = np.zeros(npoints)
bias = np.zeros(npoints)
var = np.zeros(npoints)
points = np.zeros(npoints)
z = np.ravel(z)

for j in range(1,npoints+1):
    # Making new data with different length for each j 
    x = np.arange(0,1,0.05/j)
    y = np.arange(0,1,0.05/j)
    x,y = np.meshgrid(x,y)
    z = FrankeFunction(x,y)
    z = np.ravel(z)
    print(len(z), np.shape(z))
    X = CreateDesignMatrix_X(x,y,n = 5)
    # Shuffle the indexes and then split the list
    indexes = np.arange(X.shape[0])
    np.random.shuffle(indexes)
    s = np.split(indexes,k)
    # Lists which will be filled
    errorarray = np.zeros(k)
    biasarray = np.zeros((k,len(s[0])))
    variancearray = np.zeros(k)
    # The cross validation for loop
    for i in range(k):
        # Making the test and train data
        X_test = X[s[i]]
        z_test = z[s[i]]
        a = np.delete(s,i,0)
        a = a.flatten()
        X_train = X[a]
        z_train = z[a]
        # OLS regression
        beta = np.linalg.inv(X_train.T.dot(X_train)).dot(X_train.T).dot(z_train)
        z_tilde = X_test @ beta
        # Making the train data and the error for the train data
        z_tilde_train = X_train @ beta
        trainingerrorarray[i] = np.mean((z_train - z_tilde_train)**2)
        # Calculating the error, the bias and the variance and add the to lists/matrixes
        errorarray[i] = (np.mean((z_test - z_tilde)**2))
        biasarray[i] = (z_test - np.mean(z_tilde))**2
        variancearray[i] = variance(z_tilde)
    # Calculate the mean of test error, bias, variance and the training error for the crossvalidation
    error[j-1] = np.mean(errorarray)
    bias[j-1] = np.mean(biasarray)
    var[j-1] = np.mean(variancearray)
    points[j-1] = len(z)

# Plotting the test error, bias and variance against number of datapoints
plt.figure("math")
plt.plot(points,error,"r-",label="error")
plt.plot(points,trainingerror,"b-",label="bias")
plt.plot(points,var,"g-",label="var")
plt.xlabel("Number of datapoints")
plt.title("Bias, variance and error as function of number of datapoints")
plt.legend()
plt.grid()

plt.figure("bias")
plt.plot(points,error,"r-",label="error")
plt.plot(points,bias,"b-",label="bias")
plt.plot(points,var,"g-",label="var")
plt.xlabel("Number of datapoints")
plt.title("Bias, variance and error as function of number of datapoints")
plt.legend()
plt.grid()
plt.show()

