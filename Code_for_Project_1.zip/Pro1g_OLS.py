import numpy as np
from imageio import imread
import matplotlib.pyplot as plt
from mpl_toolkits.mplot3d import Axes3D
from matplotlib import cm
from matplotlib.ticker import LinearLocator, FormatStrFormatter
np.random.seed(0)
# Load the terrain
terrain = imread("Oslofjord.tif")

# Making the x and y points
x = np.linspace(0,1,1801)
y = np.linspace(0,1,3601)
x,y = np.meshgrid(x,y)

def CreateDesignMatrix_X(x, y, n = 5):
    """
    Function for creating a design X-matrix with rows [1, x, y, x^2, xy, xy^2 , etc.]
    Input is x and y mesh or raveled mesh, keyword agruments n is the degree of the polynomial you want to fit.
    """
    if len(x.shape) > 1:
        x = np.ravel(x)
        y = np.ravel(y)

    N = len(x)
    l = int((n+1)*(n+2)/2)		# Number of elements in beta
    X = np.ones((N,l))

    for i in range(1,n+1):
        q = int((i)*(i+1)/2)
        for k in range(i+1):
            X[:,q+k] = x**(i-k)*y**k
    return X

def variance(y):
    ey = np.zeros(len(y))
    ey[:] = 1./(len(y))*np.sum(y)
    return(1./(len(y)))*np.sum((y - ey)**2)

def MSE(y,y_tilde):
    return(1/len(y))*np.sum((y - y_tilde)**2)

def R2score(y,y_tilde):
    ey = np.zeros(len(y_tilde))
    ey[:] = 1./(len(y_tilde))*np.sum(y_tilde)
    return 1 - sum((y - y_tilde)**2)/sum((y - ey)**2)

# Fit the terrain using the OLS method
z = np.ravel(terrain)
# Calling the design matrix
X = CreateDesignMatrix_X(x,y,n = 5)
# Removing some data so the data can be divided in 5. This is for the cross validation
X = np.delete(X,-1,0)
# Number of folds the datapoints is split into
k = 5
# Making a list of numbers which will act as the indexes in the resampling
indexes = np.arange(X.shape[0])
# Shuffel the indexes and then split the list
np.random.shuffle(indexes)
s = np.split(indexes,k)
# List which will be filled
errorarray = np.zeros(k)
biasarray = np.zeros((k,len(s[0])))
variancearray = np.zeros(k)
trainingerrorarray = np.zeros(k)
r2scorearray = np.zeros(k)
betas = np.zeros((21,k))
# The cross validation for loop
for i in range(k):
    # Making the test and train data
    X_test = X[s[i]]
    z_test = z[s[i]]
    a = np.delete(s,i,0)
    a = a.flatten()
    X_train = X[a]
    z_train = z[a]
    # OLS regression
    beta = np.linalg.inv(X_train.T.dot(X_train)).dot(X_train.T).dot(z_train)
    z_tilde = X_test @ beta
    # Calculating the error, the bias and the variance and add the to lists/matrixes
    errorarray[i] = np.mean((z_test - z_tilde)**2)
    biasarray[i] = (z_test - np.mean(z_tilde))**2
    variancearray[i] = variance(z_tilde)
    # Making the train data and the error for the train data
    z_tilde_train = X_train @ beta
    trainingerrorarray[i] = np.mean((z_train - z_tilde_train)**2)
    # Calculating the r2 score
    r2scorearray[i] = R2score(z_test,z_tilde)
    # Storing the betas for the 5th degree polynom
    betas[:,i] = beta
# Calculate the mean of test error, bias, variance and the training error for the crossvalidation
error = np.mean(errorarray)
bias = np.mean(biasarray)
var = np.mean(variancearray)
trainingerror = np.mean(trainingerrorarray)
r2score = np.mean(r2scorearray)
for i in range(len(beta)):
    beta[i] = np.mean(betas[i,:])

print("Mean error for OLS is", error)
print("Mean r2 score for OLS is", r2score)

# Function for confidence interval
def confidence(beta,error):
    V=np.diag(np.linalg.inv(X.T.dot(X)))
    for i in range(len(beta)):
        mini.append(beta[i]-1.96*V[i]**(0.5)*error)
        maxi.append(beta[i]+1.96*V[i]**(0.5)*error)
        
# Plots and prints out the confidence interval of beta using the optimal lambda
mini=[]
maxi=[]
confidence(beta,np.sqrt(variance(z)))
print(maxi)
plt.figure("Beta, Beta min, Beta max")
plt.title("Beta, Beta min, Beta max")
plt.plot(range(len(beta)),beta,"r",label="Beta")
plt.plot(range(len(beta)),mini,"b",label="Beta min")
plt.plot(range(len(beta)),maxi,"g",label="Beta max")
plt.legend()
plt.grid()

X = CreateDesignMatrix_X(x,y,n = 5)
z_tilde = X @ beta

# Reshape for plotting
z_tilde = z_tilde.reshape(3601,1801)
z = z.reshape(3601,1801)

# Plotting the surfaces
fig = plt.figure()
ax = fig.gca(projection='3d')
surf = ax.plot_surface(y, x, z_tilde, cmap=cm.coolwarm,
                       linewidth=0, antialiased=False)
ax.set_xlabel('Y')
ax.set_ylabel('X')
ax.set_zlabel('Z')
# Customize the z axis.
ax.set_zlim(-0.1, 1380)
ax.zaxis.set_major_locator(LinearLocator(10))
ax.zaxis.set_major_formatter(FormatStrFormatter('%.02f'))
# Add a color bar which maps values to colors.
fig.colorbar(surf, shrink=0.5, aspect=5)

# Plotting the surfaces
fig = plt.figure()
ax = fig.gca(projection='3d')
surf = ax.plot_surface(y, x, z, cmap=cm.coolwarm,
                       linewidth=0, antialiased=False)
ax.set_xlabel('Y')
ax.set_ylabel('X')
ax.set_zlabel('Z')
# Customize the z axis.
ax.set_zlim(-0.1, 1380)
ax.zaxis.set_major_locator(LinearLocator(10))
ax.zaxis.set_major_formatter(FormatStrFormatter('%.02f'))
# Add a color bar which maps values to colors.
fig.colorbar(surf, shrink=0.5, aspect=5)

# Show the terrain
plt.figure()
plt.title('Terrain over Oslofjord')
plt.imshow(terrain, cmap='gnuplot')
plt.xlabel('X')
plt.ylabel('Y')

# Show the terrain
plt.figure()
plt.title('Approximated terrain over Oslofjord')
plt.imshow(z_tilde, cmap='gnuplot')
plt.xlabel('X')
plt.ylabel('Y')

plt.show()
