import numpy as np
from imageio import imread
import matplotlib.pyplot as plt
from mpl_toolkits.mplot3d import Axes3D
from matplotlib import cm

# Load the terrain
terrain = imread('Oslofjord.tif')

# Show the terrain
plt.figure()
plt.title('Terrain over Oslofjord')
plt.imshow(terrain, cmap='gnuplot')
plt.xlabel('X')
plt.ylabel('Y')
plt.show()
