import numpy as np
from random import random, seed
from sklearn.metrics import mean_squared_error

# To keep the same eps in the FrankeFunction
np.random.seed(0)

# Make data.
x = np.arange(0, 1, 0.05)
y = np.arange(0, 1, 0.05)
x, y = np.meshgrid(x,y)


def FrankeFunction(x,y):
    term1 = 0.75*np.exp(-(0.25*(9*x-2)**2) - 0.25*((9*y-2)**2))
    term2 = 0.75*np.exp(-((9*x+1)**2)/49.0 - 0.1*(9*y+1))
    term3 = 0.5*np.exp(-(9*x-7)**2/4.0 - 0.25*((9*y-3)**2))
    term4 = -0.2*np.exp(-(9*x-4)**2 - (9*y-7)**2)
    eps = 0.01*np.random.randn(len(x),1)
    return term1 + term2 + term3 + term4 + eps


z = FrankeFunction(x, y)

def CreateDesignMatrix_X(x, y, n = 5):
	"""
	Function for creating a design X-matrix with rows [1, x, y, x^2, xy, xy^2 , etc.]
	Input is x and y mesh or raveled mesh, keyword agruments n is the degree of the polynomial you want to fit.
	"""
	if len(x.shape) > 1:
		x = np.ravel(x)
		y = np.ravel(y)

	N = len(x)
	l = int((n+1)*(n+2)/2)		# Number of elements in beta
	X = np.ones((N,l))

	for i in range(1,n+1):
		q = int((i)*(i+1)/2)
		for k in range(i+1):
			X[:,q+k] = x**(i-k)*y**k
	return X

# Calling the design matrix and ravel the z values   
X = CreateDesignMatrix_X(x,y,n=5)
z = np.ravel(z)

# Making a list of numbers which will act as the indexes in the resampling
indexes = np.arange(X.shape[0])
np.random.shuffle(indexes) # Shuffel the indexes and then split the list in 5
s = np.split(indexes,5)

# Will be filled with MSEs
scores = np.zeros(5)
scores_sklearn = np.zeros(5)

# Mean squared error function
def MSE(y,y_tilde):
    return(1/len(y))*np.sum((y - y_tilde)**2)

# The cross validation for loop
for i in range(5):
    # making the test and train data
    X_test = X[s[i]]
    z_test = z[s[i]]
    a = np.delete(s,i,0)
    a = a.flatten()
    X_train = X[a]
    z_train = z[a]
    # OLS regression
    beta = np.linalg.inv(X_train.T.dot(X_train)).dot(X_train.T).dot(z_train)
    z_tilde = X_test @ beta
    # making the MSEs
    zmse = MSE(z_test,z_tilde)
    zmse_sklearn = mean_squared_error(z_test,z_tilde)
    scores[i] = zmse
    scores_sklearn[i] = zmse_sklearn

# Finding which resampling that gives the lowest MSE
result = np.where(scores == np.min(scores))
result_sklearn = np.where(scores_sklearn == np.min(scores_sklearn))
print("_____MSE form own code_____")
print(scores)
print("_____MSE form SciKitLearn code_____")
print(scores_sklearn)
print("_____Resample that gives the lowest MSE_____")
print("Own code: %i" %result[0])
print("SciKitLearn code: %i" %result_sklearn[0])






