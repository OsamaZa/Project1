import numpy as np
from random import random, seed
import matplotlib.pyplot as plt
from sklearn.linear_model import Lasso

# To keep the same eps in the FrankeFunction
np.random.seed(0)

# Make data.
x = np.arange(0, 1, 0.05)
y = np.arange(0, 1, 0.05)
x, y = np.meshgrid(x,y)


def FrankeFunction(x,y):
    term1 = 0.75*np.exp(-(0.25*(9*x-2)**2) - 0.25*((9*y-2)**2))
    term2 = 0.75*np.exp(-((9*x+1)**2)/49.0 - 0.1*(9*y+1))
    term3 = 0.5*np.exp(-(9*x-7)**2/4.0 - 0.25*((9*y-3)**2))
    term4 = -0.2*np.exp(-(9*x-4)**2 - (9*y-7)**2)
    eps = 0.01*np.random.randn(len(x),1)
    return term1 + term2 + term3 + term4 + eps


z = FrankeFunction(x, y)

def CreateDesignMatrix_X(x, y, n = 5):
	"""
	Function for creating a design X-matrix with rows [1, x, y, x^2, xy, xy^2 , etc.]
	Input is x and y mesh or raveled mesh, keyword agruments n is the degree of the polynomial you want to fit.
	"""
	if len(x.shape) > 1:
		x = np.ravel(x)
		y = np.ravel(y)

	N = len(x)
	l = int((n+1)*(n+2)/2)		# Number of elements in beta
	X = np.ones((N,l))

	for i in range(1,n+1):
		q = int((i)*(i+1)/2)
		for k in range(i+1):
			X[:,q+k] = x**(i-k)*y**k
	return X

def variance(y):
    ey = np.zeros(len(y))
    ey[:] = 1./(len(y))*np.sum(y)
    return(1./(len(y)))*np.sum((y - ey)**2)

nlambdas = 5 # Number of lambdas
lambdas = np.logspace(-8,-6,nlambdas) # Lambdas used in the for-loop
k = 5 # k=5 cross validation
d = 0
npoints = 5 # Different length of amount of data points
z = np.ravel(z)
# loop for the bias-variance tradeoff with respect to number of datapoints
for lmb in lambdas:
    # Lists to be filled with results
    error = np.zeros(npoints)
    bias = np.zeros(npoints)
    var = np.zeros(npoints)
    trainingerror = np.zeros(npoints)
    points = np.zeros(npoints)
    # For-loop for making new lenghts of data for each iteration
    for j in range(1,npoints+1):
        x = np.arange(0,1,0.05/j)
        y = np.arange(0,1,0.05/j)
        x,y = np.meshgrid(x,y)
        z = FrankeFunction(x,y)
        z = np.ravel(z)
        # Calling the design matrix with degree n. Change n will give another polynomial      
        X = CreateDesignMatrix_X(x,y,n = 5)
        X = X[:,1:]
        # Making a list of numbers which will act as the indexes in the resampling
        indexes = np.arange(X.shape[0])
        np.random.shuffle(indexes)
        # Shuffle the indexes and splits them
        s = np.split(indexes,k)
        # Lists that will be filled
        errorarray = np.zeros(k)
        biasarray = np.zeros(k)
        variancearray = np.zeros(k)
        trainingerrorarray = np.zeros(k)
        # The cross validation for-loop
        for i in range(k):
            # Making the test and train data
            X_test = X[s[i]]
            z_test = z[s[i]]
            a = np.delete(s,i,0) # Removing the test data indexes
            a = a.flatten()
            X_train = X[a]
            z_train = z[a]
            # Lasso regression
            lasso = Lasso(alpha=lmb,max_iter = 10e4).fit(X_train,z_train)
            z_tilde = lasso.predict(X_test)
            z_tilde_train = lasso.predict(X_train) # Training data used to make an approximate
            # Calculating the error, the bias and the variance and add them to lists
            errorarray[i] = (np.mean((z_test - z_tilde)**2))
            biasarray[i] = np.mean((z_train - np.mean(z_tilde))**2)
            variancearray[i] = variance(z_tilde)
            trainingerrorarray[i] = np.mean((z_train - z_tilde_train)**2)
        # Calculate the mean of error, bias, and variance for the crossvalidation
        error[j-1] = np.mean(errorarray)
        bias[j-1] = np.mean(biasarray)
        var[j-1] = np.mean(variancearray)
        trainingerror[j-1] = np.mean(trainingerrorarray)
        points[j-1] = len(z)
    # Ploting the error, bias, and variance vs number of datapoints
    plt.figure()
    plt.plot(points,error,"r-",label="error")
    plt.plot(points,trainingerror,"b-",label="bias")
    plt.plot(points,var,"g-",label="var")
    plt.xlabel("Number of datapoints")
    plt.title("Bias, variance and error as function of number of datapoints for lambda=%.10f" %lmb)
    plt.legend()
    plt.grid()
    plt.figure()
    plt.plot(points,error,"r-",label="error")
    plt.plot(points,bias,"b-",label="trainingerror")
    plt.plot(points,var,"g-",label="var")
    plt.xlabel("Number of datapoints")
    plt.title("Bias, variance and error as function of number of datapoints for lambda=%.10f" %lmb)
    plt.legend()
    plt.grid()
    d += 1
plt.show()

